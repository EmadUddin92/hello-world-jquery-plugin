(function($){
    $.fn.helloworld = function(options){

        // Establish our default settings

        var settings = $.extend({
            text : 'Hello! World',
            color: null,
            fontStyle:null,
            complete: null
        },options);

        return this.each(function(){
          $(this).text(settings.text);

          if(settings.color){
                $(this).css('color', settings.color);
          }

          if(settings.fontStyle){
            $(this).css('fontStyle', settings.fontStyle);
            }

            if($.isFunction(settings.complete)){
                settings.complete.call(this);
            }
            
        });
    }
}(jQuery));